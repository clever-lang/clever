#include <stdio.h>

void hellmoto(){
	printf("Hello from hell!\n");
}

void add(int a, int b){
	printf("%d + %d = %d\n",a,b,a+b);
}
