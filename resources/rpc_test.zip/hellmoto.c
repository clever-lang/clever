#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void hellmoto(){
	printf("Hello from hell!\n");
}

int add(int a, int b){
	printf("%d + %d = %d\n",a,b,a+b);
	return a+b;
}

double add2(double a, double b){
	printf("%lf + %lf = %lf\n",a,b,a+b);
	return a+b;
}

void printStr(char* str){
	printf("helll <%s>\n",str);
	//printf("Str = %s\n",str);
}

char* returnStr(){
	char* str;
	str = (char*)malloc( (sizeof(int) +4 )*sizeof(char));

	int len_s=4;
	memcpy(str,&len_s,sizeof(int));
	memcpy(str+sizeof(int),"ola",3);
	str[3+sizeof(int)]='\0';
	return str;
}
