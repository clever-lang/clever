#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

void hellmoto(){
	fprintf(stderr,"Hello from hell!\n");
}

int add(int a, int b){
	return a+b;
}

double add2(double a, double b){
	return a+b;
}

void printStr(char* str){
	fprintf(stderr,"<%s>\n",str);
}

char* getStr(){
	int size=4;
	char* str =(char*) malloc(8*sizeof(char));
	memcpy(str,&size,sizeof(int));
	str[4]='O'; str[5]='L'; str[6]='A'; str[7]='\0'; 
	return str;
}
