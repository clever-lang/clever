#include <stdio.h>

void hellmoto(){
	printf("Hello from hell!\n");
}

int add(int a, int b){
	printf("%d + %d = %d\n",a,b,a+b);
	return a+b;
}

double add2(double a, double b){
	printf("%lf + %lf = %lf\n",a,b,a+b);
	return a+b;
}

void printStr(char* str){
	printf("helll <%s>\n",str);
	//printf("Str = %s\n",str);
}
