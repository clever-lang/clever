/*
nffi.c
A simple C code to test FFI support on Clever.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void hello(){
	printf("helloFFI!!!\n\n");
}

int f1(int a, int b){
	printf("a=%d b=%d a+b=%d\n",a,b,a+b);
	return a+b;
}

typedef struct{
	int a, b;
}obj;


obj cobj(int a, int b){
	obj o;
	o.a=a;
	o.b=b;
	return o;
}

void print_obj(obj o){
	printf("o.a=%d o.b=%d\n",o.a,o.b);
}


obj* pcobj( int a, int b){
	obj* o=(obj*)malloc(sizeof(obj));
	o->a=a;
	o->b=b;
	return o;
}

void print_pobj(obj* o){
	printf("o->a=%d o->b=%d\n",o->a,o->b);
}

void destroy_pobj(obj* o){
	free(o);
}

typedef struct {
	int a;
	double b;
	char* s;
}obj2;

obj2* create_obj2(int a, double b, const char* s){
	obj2* o = (obj2*)malloc(sizeof(obj2));
	o->a=a;
	o->b=b;
	o->s=(char*)malloc(strlen(s));
	strcpy(o->s,s);
	return o;
}

void destroy_obj2(obj2* o){
	free(o->s);
	free(o);
}

void print_obj2(obj2* o){
	printf(" <> o->a = %d o->b = %e o->s = %s\n",o->a,o->b,o->s);
}



